﻿const addProjectDescriptionTextarea = document.getElementById('add-project-description')
const addProjectDescriptionQuill = new Quill('#add-project-description-wysiwyg-editor', {
    modules: {
        syntax: true,
        toolbar: '#add-project-description-wysiwyg-toolbar'
    },
    theme: 'snow',
    placeholder: 'Type somthing'
});

addProjectDescriptionQuill.on('text-change', function () {
    addProjectDescriptionTextarea.value = addProjectDescriptionQuill.root.innerHTML
})



const editProjectDescriptionTextarea = document.getElementById('edit-project-description')
const editProjectDescriptionQuill = new Quill('#edit-project-description-wysiwyg-editor', {
    modules: {
        syntax: true,
        toolbar: '#edit-project-description-wysiwyg-toolbar'
    },
    theme: 'snow',
    placeholder: 'Type somthing'
});

editProjectDescriptionQuill.on('text-change', function () {
    editProjectDescriptionTextarea.value = editProjectDescriptionQuill.root.innerHTML
})





const uploadTrigger = document.getElementById('upload-trigger')
const fileInput = document.getElementById('image-upload')
const imagePreview = document.getElementById('image-preview')
const imagePreviewIcon = document.getElementById('image-preview-icon')

uploadTrigger.addEventListener('click', function () {
    fileInput.click();
})

fileInput.addEventListener('change', function (e) {
    const file = e.target.files[0]
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader()
        reader.onload = (e) => {
            imagePreview.src = e.target.result
            imagePreview.classList.remove('hide')
            imagePreviewIcon.classList.add('selected')
            imagePreviewIcon.classList.add('fa-edit')
            imagePreviewIcon.classList.remove('fa-camera')
        }
        reader.readAsDataURL(file)
    }
})






const editUploadTrigger = document.getElementById('edit-upload-trigger')
const editFileInput = document.getElementById('edit-image-upload')
const editImagePreview = document.getElementById('edit-image-preview')
const editImagePreviewIcon = document.getElementById('edit-image-preview-icon')

editUploadTrigger.addEventListener('click', function () {
    editFileInput.click();
})

editFileInput.addEventListener('change', function (e) {
    const file = e.target.files[0]
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader()
        reader.onload = (e) => {
            editImagePreview.src = e.target.result
            editImagePreview.classList.remove('hide')
            editImagePreviewIcon.classList.add('selected')
            editImagePreviewIcon.classList.add('fa-edit')
            editImagePreviewIcon.classList.remove('fa-camera')
        }
        reader.readAsDataURL(file)
    }
})














document.addEventListener('click', function (event) {
    const dropdownButtons = document.querySelectorAll('[data-type="dropdown"], .btn-actions');
    const allDropdowns = document.querySelectorAll('.dropdown');

    let clickedOnDropdown = false;

    dropdownButtons.forEach(button => {
        const targetSelector = button.getAttribute('data-target');
        const dropdown = targetSelector ? document.querySelector(targetSelector) : button.closest('.project-actions')?.querySelector('.project-dropdown');

        if (button.contains(event.target)) {
            clickedOnDropdown = true;

            allDropdowns.forEach(d => {
                if (d !== dropdown) d.classList.remove('dropdown-show');
            });

            dropdown?.classList.toggle('dropdown-show');
        }
    });

    if (!clickedOnDropdown && !event.target.closest('.dropdown')) {
        allDropdowns.forEach(d => d.classList.remove('dropdown-show'));
    }
});












const modalTriggers = document.querySelectorAll('[data-type="modal"]');

modalTriggers.forEach(trigger => {
    trigger.addEventListener('click', function () {
        const targetId = trigger.getAttribute('data-target');
        const modal = document.querySelector(targetId);
        if (modal) {
            modal.classList.add('modal-show');
        }
    });
});


const closeButtons = document.querySelectorAll('[data-type="close"]');

closeButtons.forEach(button => {
    button.addEventListener('click', function () {
        const targetId = button.getAttribute('data-target');
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            targetElement.classList.remove('modal-show');
        }
    });
});



document.querySelectorAll('.form-select').forEach(select => {
    const trigger = select.querySelector('.form-select-trigger')
    const triggerText = trigger.querySelector('.form-select-text')
    const options = select.querySelectorAll('.form-select-option')
    const hiddenInput = select.querySelector('input[type="hidden"]')
    const placeholder = select.dataset.placeholder || "Choose"

    const setValue = (value = "", text = placeholder) => {
        triggerText.textContent = text
        hiddenInput.value = value
        select.classList.toggle('has-placeholder', !value)
    };
    setValue()

    trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        document.querySelectorAll('.form-select-open')
            .forEach(el => el !== select && el.classList.remove('open'))
        select.classList.toggle('open')
    })
    options.forEach(option =>
        option.addEventListener('click', () => {
            setValue(option.dataset.value, option.textContent)
            select.classList.remove('open')
        })
    )
    document.addEventListener('click', e => {
        if (!select.contains(e.target))
            select.classList.remove('open')
    })
})




