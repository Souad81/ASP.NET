﻿using Microsoft.AspNetCore.Mvc;
using Presentation.Models;

namespace Presentation.Controllers;

public class LoginController : Controller
{
    public IActionResult Index()
    {
        return View();
    }


    [HttpPost]
    public IActionResult Index(LoginViewModel model)
    {

        if (!ModelState.IsValid)
            return View(model);

        return View();

    }
  }



 
