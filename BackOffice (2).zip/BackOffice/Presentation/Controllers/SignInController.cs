﻿using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    public class SignInController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
