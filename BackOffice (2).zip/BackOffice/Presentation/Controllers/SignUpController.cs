﻿using Microsoft.AspNetCore.Mvc;
using Presentation.Models;

namespace Presentation.Controllers;

public class SignUpController : Controller
{
    public IActionResult Index()
    {
        return View();
    }


    [HttpPost]
    public IActionResult Index(SignUpViewModel model)
    {

        if (!ModelState.IsValid) 
            return View(model);


        return View();
    }
}


